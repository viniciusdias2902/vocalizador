/* Play MP3 file from Flash(spiffs system)

   This example code is in the Public Domain (or CC0 licensed, at your option.)

   Unless required by applicable law or agreed to in writing, this
   software is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
   CONDITIONS OF ANY KIND, either express or implied.
*/
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include "esp_log.h"
#include "sdkconfig.h"

#include "audio_element.h"
#include "audio_pipeline.h"
#include "audio_event_iface.h"
#include "i2s_stream.h"
#include "spiffs_stream.h"
#include "mp3_decoder.h"

#include "esp_peripherals.h"
#include "periph_spiffs.h"
#include "board.h"

static const char *TAG = "SPIFFS_MP3_EXAMPLE";

#include "driver/i2c.h"
#define I2C_MASTER_NUM    I2C_NUM_0  // 选择I2C端口 
#define SDA_GPIO          14         // 根据硬件调整 
#define SCL_GPIO          47 
// #define SDA_GPIO          47         // 根据硬件调整 
// #define SCL_GPIO          48 
#define I2C_FREQ_HZ       400000     // 标准模式100kHz 

void i2c_master_init() {
    i2c_config_t conf = {
        
        .mode = I2C_MODE_MASTER,
        .sda_io_num = SDA_GPIO,
        .scl_io_num = SCL_GPIO,
        .sda_pullup_en = GPIO_PULLUP_DISABLE,  // 依赖硬件上拉设计 
        .scl_pullup_en = GPIO_PULLUP_DISABLE,
        .master.clk_speed  = I2C_FREQ_HZ ,
        // .clk_flags = I2C_SCLK_SRC_FLAG_FOR_NOMAL,  // 新增时钟源标识 
        // .intr_priority = 0
    };
    ESP_ERROR_CHECK(i2c_param_config(I2C_MASTER_NUM, &conf));
    ESP_ERROR_CHECK(i2c_driver_install(I2C_MASTER_NUM, conf.mode,  512, 512, 0));
}

void advanced_i2c_scan() {
    uint8_t found = 0;
    for (int addr = 0x08; addr <= 0x77; addr++) {
        for (int retry = 0; retry < 3; retry++) {  // 三次重试 
            i2c_cmd_handle_t cmd = i2c_cmd_link_create();
            i2c_master_start(cmd);
            i2c_master_write_byte(cmd, (addr << 1) | I2C_MASTER_WRITE, true);
            i2c_master_stop(cmd);
            esp_err_t ret = i2c_master_cmd_begin(I2C_NUM_0, cmd, 100 / portTICK_PERIOD_MS);
            i2c_cmd_link_delete(cmd);
            
            if (ret == ESP_OK) {
                printf("设备地址 0x%02X 验证成功\n", addr);
                found++;
                break;
            } else if (ret == ESP_ERR_TIMEOUT) {
                i2c_reset_tx_fifo(I2C_NUM_0);  // 超时自动恢复总线 
            }
        }
    }
    printf("共发现 %d 个设备\n", found);
}

#include "es8388.h"
i2s_chan_handle_t tx_handle;
void i2s_init(void)
{
    /* 通道配置（层级1：通用参数） */
    i2s_chan_config_t tx_handle_cfg = {
        .id = I2S_NUM_0,         // 选择 I2S 端口号
        .role = I2S_ROLE_MASTER, // 主模式
        .dma_desc_num = 3,       // DMA 缓冲区数量
        .dma_frame_num = 300,    // 每个缓冲区的帧数
        .auto_clear = false,     // 禁用自动清理（需手动处理）
        // .intr_priority = 1       // 中断优先级
    };
    // 创建新的I2S通道
    i2s_new_channel(&tx_handle_cfg, &tx_handle, NULL);
    
    /* 标准模式配置（层级2：协议参数） */
    i2s_std_config_t tx_std_cfg = {
        .clk_cfg = I2S_STD_CLK_DEFAULT_CONFIG(44100), // 采样率生成器
        .slot_cfg = {
            .data_bit_width = I2S_SLOT_BIT_WIDTH_16BIT, // 总数据位宽
            .slot_bit_width = I2S_SLOT_BIT_WIDTH_16BIT, // 单声道位宽
            .slot_mode = I2S_SLOT_MODE_MONO,          // 立体声模式
            .slot_mask = I2S_STD_SLOT_LEFT,             // 双声道使能
            .ws_width = 16,                             // 帧同步信号宽度
            .ws_pol = true,                            // 左对齐时序
            .bit_shift = true,                          // 启用位偏移
        },
        .gpio_cfg = {.mclk = 8,          // 禁用主时钟
                     .bclk = 3, // 位时钟
                     .ws = 9,     // 字选择时钟
                     .dout = 10,          // 禁用输出
                     .din = 46,   // 数据输入
                     .invert_flags = {.mclk_inv = false, .bclk_inv = false, .ws_inv = false}}};

    // 初始化I2S通道的标准模式
    i2s_channel_init_std_mode(tx_handle, &tx_std_cfg);
}
const uint8_t pcm_start[] asm("_binary_xiaotudou1_pcm_start");
const uint8_t pcm_end[]   asm("_binary_xiaotudou1_pcm_end");

void i2s_play_music(void)
{
    size_t b_write = 0;
    uint8_t *data_ptr = (uint8_t *)pcm_start;

    ESP_ERROR_CHECK(i2s_channel_preload_data(tx_handle,data_ptr,pcm_end-data_ptr,&b_write));
    data_ptr +=b_write;
    ESP_ERROR_CHECK(i2s_channel_enable(tx_handle));
    while(1)
    {
        if(i2s_channel_write(tx_handle,data_ptr,pcm_end-data_ptr,&b_write,0)==ESP_OK){
            printf("Write Task: i2s write %d bytes\n", b_write);
        } else {
            printf("Write Task: i2s write failed\n");
        }
        if(b_write>0)
        {
             printf("[music] i2s music played, %d bytes are written.", b_write);
        }
        else {
           printf("[music] i2s music play failed.");
        }
        data_ptr = (uint8_t *)pcm_start;
        vTaskDelay(1000 / portTICK_PERIOD_MS);
    }
    ESP_ERROR_CHECK(i2s_channel_disable(tx_handle));
}

/**
 * @brief 主应用程序函数，用于从SPIFFS文件系统播放MP3文件。
 *
 * 此函数初始化音频管道，包括从SPIFFS读取MP3文件、解码MP3文件并通过I2S输出音频。
 * 它还处理音频事件，如音乐信息报告和播放结束事件。
 *
 * @param 无
 * @return 无
 */
void app_main(void)
{
    // i2s_init();
    // i2s_channel_enable(tx_handle);
    
    // audio_hal_codec_config_t audio_codec_cfg = AUDIO_CODEC_DEFAULT_CONFIG();

    // es8388_init(&audio_codec_cfg);

    // es8388_config_fmt(ES_MODULE_DAC,ES_I2S_LEFT);
    // es8388_set_voice_volume(0);
    // es8388_set_bits_per_sample(ES_MODULE_DAC,BIT_LENGTH_16BITS);
    // es8388_set_voice_mute(1);

    // audio_hal_codec_i2s_iface_t i2s_iface = {
    //     .mode=AUDIO_HAL_MODE_SLAVE,
    //     .fmt = AUDIO_HAL_I2S_LEFT,
    //     .bits = BIT_LENGTH_16BITS,
    //     .samples = 44100,
    // };
    // es8388_config_i2s(ES_MODULE_DAC,&i2s_iface);

    // es8388_config_dac_output(DAC_OUTPUT_LOUT1|DAC_OUTPUT_ROUT1);

    // es8388_ctrl_state(AUDIO_HAL_CODEC_MODE_DECODE,AUDIO_HAL_CTRL_START);

    // advanced_i2c_scan();

    // es8388_write_reg(ES8388_DACCONTROL3, 0x00);  // 关闭DAC

// printf("es8388_init ok\n");
    // i2s_channel_enable(tx_handle);
    // i2s_play_music();
    // i2s_channel_disable(tx_handle);



    // while (1)
    // {
    //     /* code */
    //     //延时
    //     vTaskDelay(1000 / portTICK_PERIOD_MS);
    // }
    

    // 定义音频管道句柄和音频元素句柄
    audio_pipeline_handle_t pipeline;
    audio_element_handle_t spiffs_stream_reader, i2s_stream_writer, mp3_decoder;

    // 设置日志级别，将所有日志级别设置为警告，将当前示例的日志级别设置为信息
    // esp_log_level_set("*", ESP_LOG_WARN);
    // esp_log_level_set(TAG, ESP_LOG_INFO);

    // 初始化外设管理
    // 配置外设集，使用默认配置
    esp_periph_config_t periph_cfg = DEFAULT_ESP_PERIPH_SET_CONFIG();
    // 初始化外设集
    esp_periph_set_handle_t set = esp_periph_set_init(&periph_cfg);

    // 挂载SPIFFS文件系统
    ESP_LOGI(TAG, "[ 1 ] Mount spiffs");
    // 配置SPIFFS外设
    periph_spiffs_cfg_t spiffs_cfg = {
        .root = "/spiffs",          // 挂载点
        .partition_label = NULL,    // 分区标签
        .max_files = 5,             // 最大文件数
        .format_if_mount_failed = true // 如果挂载失败则格式化
    };
    // 初始化SPIFFS外设
    esp_periph_handle_t spiffs_handle = periph_spiffs_init(&spiffs_cfg);
    // 启动SPIFFS外设
    esp_periph_start(set, spiffs_handle);

    // 等待SPIFFS挂载完成
    while (!periph_spiffs_is_mounted(spiffs_handle)) {
        // 每500ms检查一次
        vTaskDelay(500 / portTICK_PERIOD_MS);
    }

    // 启动编解码器芯片
    ESP_LOGI(TAG, "[ 2 ] Start codec chip");
    // 初始化音频板
    audio_board_handle_t board_handle = audio_board_init();

    int volume = 0;

    board_handle->audio_hal->audio_codec_set_volume(100);

    // 启动编解码器芯片的解码模式
    audio_hal_ctrl_codec(board_handle->audio_hal, AUDIO_HAL_CODEC_MODE_DECODE, AUDIO_HAL_CTRL_START);

    // 创建音频管道用于播放
    ESP_LOGI(TAG, "[3.0] Create audio pipeline for playback");
    // 配置音频管道，使用默认配置
    audio_pipeline_cfg_t pipeline_cfg = DEFAULT_AUDIO_PIPELINE_CONFIG();
    // 初始化音频管道
    pipeline = audio_pipeline_init(&pipeline_cfg);
    // 检查音频管道是否初始化成功
    AUDIO_NULL_CHECK(TAG, pipeline, return);

    // 创建SPIFFS流以从闪存读取数据
    ESP_LOGI(TAG, "[3.1] Create spiffs stream to read data from sdcard");
    // 配置SPIFFS流，使用默认配置
    spiffs_stream_cfg_t flash_cfg = SPIFFS_STREAM_CFG_DEFAULT();
    // 设置为读取器类型
    flash_cfg.type = AUDIO_STREAM_READER;
    // 初始化SPIFFS流
    spiffs_stream_reader = spiffs_stream_init(&flash_cfg);

    // 创建I2S流以将数据写入编解码器芯片
    ESP_LOGI(TAG, "[3.2] Create i2s stream to write data to codec chip");
    #if 0
        // 如果是ESP32_C3_LYRA_V2_BOARD，使用PDM_TX默认配置
        i2s_stream_cfg_t i2s_cfg = I2S_STREAM_PDM_TX_CFG_DEFAULT();
    #else
        // 其他情况使用默认配置
        i2s_stream_cfg_t i2s_cfg = I2S_STREAM_CFG_DEFAULT();

        i2s_cfg.transmit_mode = I2S_COMM_MODE_STD;
        i2s_cfg.std_cfg.slot_cfg.slot_mode = I2S_SLOT_MODE_MONO;
        i2s_cfg.std_cfg.slot_cfg.slot_mask =I2S_STD_SLOT_LEFT;
        i2s_cfg.std_cfg.slot_cfg.slot_bit_width=I2S_SLOT_BIT_WIDTH_16BIT;
        i2s_cfg.std_cfg.clk_cfg.mclk_multiple=I2S_MCLK_MULTIPLE_256;
        i2s_cfg.std_cfg.clk_cfg.sample_rate_hz=44100;
    #endif
    // 设置为写入器类型
    i2s_cfg.type = AUDIO_STREAM_WRITER;
    // 初始化I2S流
    i2s_stream_writer = i2s_stream_init(&i2s_cfg);

    // 创建MP3解码器以解码MP3文件
    ESP_LOGI(TAG, "[3.3] Create mp3 decoder to decode mp3 file");
    // 配置MP3解码器，使用默认配置
    mp3_decoder_cfg_t mp3_cfg = DEFAULT_MP3_DECODER_CONFIG();
    // 初始化MP3解码器
    mp3_decoder = mp3_decoder_init(&mp3_cfg);

    // 注册所有音频元素到音频管道
    ESP_LOGI(TAG, "[3.4] Register all elements to audio pipeline");
    audio_pipeline_register(pipeline, spiffs_stream_reader, "spiffs");
    audio_pipeline_register(pipeline, mp3_decoder, "mp3");
    audio_pipeline_register(pipeline, i2s_stream_writer, "i2s");
    // 链接音频元素
    ESP_LOGI(TAG, "[3.5] Link it together [flash]-->spiffs-->mp3_decoder-->i2s_stream-->[codec_chip]");
    // 定义链接标签
    const char *link_tag[3] = {"spiffs", "mp3", "i2s"};
    // 链接音频元素
    audio_pipeline_link(pipeline, &link_tag[0], 3);

    // 设置音频元素的URI
    ESP_LOGI(TAG, "[3.6] Set up  uri (file as spiffs, mp3 as mp3 decoder, and default output is i2s)");
    // 设置SPIFFS流的URI
    audio_element_set_uri(spiffs_stream_reader, "/spiffs/Apple.mp3");

    // 设置事件监听器
    ESP_LOGI(TAG, "[ 4 ] Set up  event listener");
    // 配置音频事件接口，使用默认配置
    audio_event_iface_cfg_t evt_cfg = AUDIO_EVENT_IFACE_DEFAULT_CFG();
    // 初始化音频事件接口
    audio_event_iface_handle_t evt = audio_event_iface_init(&evt_cfg);

    // 监听音频管道中所有元素的事件
    ESP_LOGI(TAG, "[4.1] Listening event from all elements of pipeline");
    audio_pipeline_set_listener(pipeline, evt);

    // 监听外设的事件
    ESP_LOGI(TAG, "[4.2] Listening event from peripherals");
    audio_event_iface_set_listener(esp_periph_set_get_event_iface(set), evt);

    // 启动音频管道
    ESP_LOGI(TAG, "[ 5 ] Start audio_pipeline");
    audio_pipeline_run(pipeline);

    // 监听所有音频管道事件
    ESP_LOGI(TAG, "[ 6 ] Listen for all pipeline events");
    while (1) {
        // 定义音频事件消息结构体
        audio_event_iface_msg_t msg;
        // 监听音频事件
        esp_err_t ret = audio_event_iface_listen(evt, &msg, portMAX_DELAY);
        if (ret != ESP_OK) {
            // 如果监听失败，记录错误日志
            ESP_LOGE(TAG, "[ * ] Event interface error : %d", ret);
            continue;
        }

        // 处理音乐信息报告事件
        if (msg.source_type == AUDIO_ELEMENT_TYPE_ELEMENT && msg.source == (void *) mp3_decoder
            && msg.cmd == AEL_MSG_CMD_REPORT_MUSIC_INFO) {
            // 定义音乐信息结构体
            audio_element_info_t music_info = {0};
            // 获取音乐信息
            audio_element_getinfo(mp3_decoder, &music_info);

            // 记录音乐信息
            ESP_LOGI(TAG, "[ * ] Receive music info from mp3 decoder, sample_rates=%d, bits=%d, ch=%d",
                     music_info.sample_rates, music_info.bits, music_info.channels);

            // 设置I2S流的时钟
            i2s_stream_set_clk(i2s_stream_writer, music_info.sample_rates, music_info.bits, music_info.channels);
            continue;
        }

        // 处理播放结束事件
        if (msg.source_type == AUDIO_ELEMENT_TYPE_ELEMENT && msg.source == (void *) i2s_stream_writer
            && msg.cmd == AEL_MSG_CMD_REPORT_STATUS
            && (((int)msg.data == AEL_STATUS_STATE_STOPPED) || ((int)msg.data == AEL_STATUS_STATE_FINISHED))) {
            // 记录停止事件
            ESP_LOGW(TAG, "[ * ] Stop event received");
            break;
        }
    }

    // 停止音频管道
    ESP_LOGI(TAG, "[ 7 ] Stop audio_pipeline");
    audio_pipeline_stop(pipeline);
    audio_pipeline_wait_for_stop(pipeline);
    audio_pipeline_terminate(pipeline);

    // 注销音频元素
    audio_pipeline_unregister(pipeline, spiffs_stream_reader);
    audio_pipeline_unregister(pipeline, i2s_stream_writer);
    audio_pipeline_unregister(pipeline, mp3_decoder);

    // 在移除监听器之前终止音频管道
    audio_pipeline_remove_listener(pipeline);

    // 在移除监听器之前停止所有外设
    esp_periph_set_stop_all(set);
    audio_event_iface_remove_listener(esp_periph_set_get_event_iface(set), evt);

    // 在销毁事件接口之前确保移除了监听器
    audio_event_iface_destroy(evt);

    // 释放所有资源
    audio_pipeline_deinit(pipeline);
    audio_element_deinit(spiffs_stream_reader);
    // audio_element_deinit(i2s_stream_writer);
    audio_element_deinit(mp3_decoder);
    esp_periph_set_destroy(set);
}
